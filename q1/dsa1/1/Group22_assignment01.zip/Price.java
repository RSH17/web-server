import java.util.*;
import java.io.*;



class HashTable{
	private int maxSize;
	private int[] priceLimits;
	private int[] flag;
	
	public HashTable(int capacity){
		maxSize = capacity;
		priceLimits = new int[maxSize];
		flag = new int[maxSize];
		
	}
	
	public void insert(int limit){
		int pos = getHash(limit);
		int i=pos;
		do{
			if(priceLimits[i] == 0){
				priceLimits[i] = limit;
				flag[i] = 0;
				return;
			}
			i = (i+1)%maxSize;
		}while(i != pos);
		
	}
	
	private int getHash(Integer key){
		int hash = key.hashCode();
		hash %= maxSize;
		if(hash < 0){
			hash += maxSize;
		}
		return hash;
	}
	
	public void check(int[] prices){
		for(int i=0;i<maxSize;i++){
			for(int j=0;j<prices.length;j++){
				if(contains(prices,priceLimits[i]-prices[j],j)){
					flag[i]=1;
					break;
				}
			}
		}
	}
	
	public boolean contains(int[] prices, int v, int skip){
		boolean result = false;
		for(int k=0;k<prices.length;k++){
			if(prices[k]==v && k != skip){
				result = true;
				break;
			}
		}
		return result;
	}
	
	public void display(){
		System.out.println();
		for(int i=0;i<maxSize;i++){
			System.out.println(priceLimits[i] + " : " + flag[i]);		
		}
	}
}


class Price{
	public static void main(String args[]){
		
		try{
			
			File file = new File("PriceList.txt");
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String line;
			int[] prices = new int[100000];
			
			int i=0;
			while((line=br.readLine()) != null){
				prices[i] = Integer.parseInt(line);
				i++;
			}
			fr.close();
			
			Scanner input = new Scanner(System.in);
			System.out.print("No of companies : ");
			int num = input.nextInt();
			
			HashTable ht = new HashTable(num);
			System.out.print("Affordable money amounts(space seperated) : ");
			for(int j=0;j<num;j++){
				ht.insert(input.nextInt());
			}
			ht.check(prices);
			ht.display();
		}catch(IOException e){
			e.printStackTrace();
		}

		
	}
}
