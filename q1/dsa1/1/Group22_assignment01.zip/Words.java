import java.util.*;
import java.io.*;


class HashTable{
	private maxSize;
	private int[] keys;
	private String[] words;
	
	public HashTable(int capacity){
		maxSize = capacity;
		keys = new int[maxSize];
		words = new String[maxSize];
		
	}
	
	public void insert(String line){
		int val = getIntegerValue(line);
		int pos = getHash(val);
		int i=pos;
		do{
			if(keys[i] == 0){
				keys[i] = val;
				words[i] = line;
				return;
			}
			i = (i+1)%maxSize;
		}while(i != pos);
		
	}
	
	private int getIntegerValue(String key){
		int val=0;
		for(int i=0;i<key.length();i++){
			val += key.charAt(i);
		}
		return val;
	}
	
	private int getHash(int val){
		int hash = val%maxSize;
		return hash;
	}
	
	public void display(){
		System.out.println();
		for(int i=0;i<maxSize;i++){
			int temp=0;
			if(keys[i] != 0){
				for(int j=i+1;j<maxSize;j++){
					if(keys[i] == keys[j]){
						char sortedWord1[] = words[i].toCharArray();
						Arrays.sort(sortedWord1);
						
						char sortedWord2[] = words[j].toCharArray();
						Arrays.sort(sortedWord2);
						
						if(Arrays.equals(sortedWord1, sortedWord2)){
							if(temp == 0){
								System.out.print(words[i] + " ");
							}
							System.out.print(words[j] + " ");
							keys[j]=0;
							temp++;
						}		
						
					}
				}
			}
			if(temp > 0){
				System.out.println();
			}		
		}
	}
}


class Words{
	public static void main(String args[]){
		
		try{
			
			File file = new File("WordList.txt");
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String line;
			HashTable ht = new HashTable(200);
			while((line=br.readLine()) != null){
				ht.insert(line);
			}
			fr.close();
			ht.display();
		}catch(IOException e){
			e.printStackTrace();
		}

		
	}
}






